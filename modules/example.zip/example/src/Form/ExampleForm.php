<?php
/**
* @file
* Contains \Drupal\resume\Form\ResumeForm.
*/

namespace Drupal\example\Form;
use Drupal\Core\Database\Connection;
use Drupal\Core\Database\Query\SelectInterface;
use Drupal\Core\Database\Query\Condition;
use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormState;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Database\Query\TableSortExtender;
use Drupal\Core\Database\Query\PagerSelectExtender;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Drupal\Core\Url;

class ExampleForm extends FormBase {

/*
  protected $database;

  /**
   * {@inheritdoc}
   



  public static function create(ContainerInterface $container) {
    return new static(
      $container->get('database')
    );
  }

  /**
   * Constructs a \Drupal\simpletest\Form\SimpletestResultsForm object.
   *
   * @param \Drupal\Core\Database\Connection $database
   *   The database connection service.
   */

/*
  public function __construct(Connection $database) {
    $this->database = $database;
  }


/*
* {@inheritdoc}
*/

public function getFormId() {
return 'Example_form';
}

//form creation//

 public function buildForm(array $form, FormStateInterface $form_state) {


    $form['candidate_name'] = array(
      '#type' => 'textfield',
      '#title' => t('Name:'),
      // '#required' => TRUE,
    );
    $form['candidate_mail'] = array(
      '#type' => 'email',
      '#title' => t('Email ID:'),
      // '#required' => TRUE,
    );
    $form['candidate_number'] = array(
      '#type' => 'tel',
      '#title' => t('Mobile No'),
      // '#required' => TRUE
    );
    
    /*
    $form['candidate_dob'] = array(
      '#type' => 'date',
      '#title' => t('DOB'),
      // '#required' => TRUE,
    );

    */

    $form['candidate_gender'] = array(
      '#type' => 'select',
      '#title' => ('Gender'),
      '#options' => array(
        'Female' => t('Female'),
        'male' => t('Male'),
      ),
      
    );

/*
    $form['candidate_confirmation'] = array (
      '#type' => 'radios',
      '#title' => ('Are you above 18 years old?'),
      '#options' => array(
        'Yes' =>t('Yes'),
        'No' =>t('No')
      ),

    );
    */

    $form['actions']['#type'] = 'actions';
    $form['actions']['submit'] = array(
      '#type' => 'submit',
      '#value' => $this->t('Save'),
      '#button_type' => 'primary',

);


    /*

    $form['table'] = array(
      '#markup' => drupal_render($this->ViewData())
    );

  }  */

return $form;

}

/*



public function viewData() {
  $query = $this->database->select('exampleform','ef');
  $query->fields('ef', array('nid', 'name', 'email','number'));

  // Build the table header.
 
  $header = array(
    array('Nid', 'field' => 'nid'),
    t('Name'),
    t('Email'),
    t('Number'),
    t('Edit Operation'),
    t('Delete Operation'),
  );


  $url = Url::fromRoute('example.form');
  $internal_link = \Drupal::l(t('Edit'), $url);
  $internal_link2 = \Drupal::l(t('Delete'), $url);


  $table_sort = $query->extend('Drupal\Core\Database\Query\TableSortExtender')->orderByHeader($header);
  $pager = $table_sort->extend('Drupal\Core\Database\Query\PagerSelectExtender')->limit(5);
  $result = $pager->execute()->fetchAll();

  foreach($result as $row) {

    $rows[] = array(
      $row->nid,
      $row->name,
      $row->email,
      $row->number,
      $internal_link,
      $internal_link2,

    );
  }

  $build = array(
      '#markup' =>t('Results')
  );

  $build['exampleform_table'] = array(
    '#theme' => 'table', '#header' => $header,
      '#rows' => $rows,
  );
 $build['pager'] = array(
   '#type' => 'pager'
 );
 return $build;

}

*/


//validation
  

/*
  public function validateForm(array &$form, FormStateInterface $form_state) {
    if (strlen($form_state->getValue('candidate_number')) < 10) {
    $form_state->setErrorByName('candidate_number', $this->t('Mobile number is too short.'));
    
*/



// submission

  public function submitForm(array &$form, FormStateInterface $form_state) {

   foreach ($form_state->getValues() as $key => $value) {
      drupal_set_message($key . ': ' . $value);

   }

db_insert('ExampleForm')->fields(array(
       'name' => $form_state->getValue('candidate_name'),
       'gender' => $form_state->getValue('candidate_gender'),
       'email' => $form_state->getValue('candidate_mail'),
       'number' => $form_state->getValue('candidate_number'),   
     ))->execute();
     drupal_set_message(t('successfully entered the data'));


     //restore



/*restore

*/

}
}
