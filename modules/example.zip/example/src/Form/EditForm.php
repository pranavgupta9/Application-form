<?php
/**
 * @file
 * Contains \Drupal\example\Form\ContributeForm.
 */

namespace Drupal\example\Form;
use Drupal\Core\Database\Connection;
use Drupal\Core\Database\Query\SelectInterface;
use Drupal\Core\Database\Query\Condition;
use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormState;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Component\Utility\UrlHelper;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Drupal\Core\Url;
use Drupal\example\Controller\Databaselist;

/**
 * Contribute form.
 */
class EditForm extends FormBase {
  /**
   * {@inheritdoc}
   */
  public function getFormId() {
  	return 'edit_form';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {


   $path = \Drupal::request()->getQueryString();
   $arg = explode('=', $path); 
// $param_node = isset($arg[0]) ? $arg[0] : '';
   $nid = isset($arg[1]) ? $arg[1] : '';
   if (!empty($nid)) {
 //  if (!empty($nid) && $param_node == 'nid') {
    $data = Databaselist::provideData($nid);
    $name = $data->name;
    $email = $data->email;
    $number = $data->number;
  }

   else {
    $name = '';
    $email = '';
    $number = '';

   } 

  	$form['candidate_name'] = array(
      '#type' => 'textfield',
      '#title' => t('Name'),
      '#required' => TRUE,
      '#default_value' => $name,
    );

    $form['candidate_mail'] = array(
      '#type' => 'email',
      '#title' => t('Email Id'),
      '#required' => TRUE,
      '#default_value' => $email,
    );

    $form['candidate_number'] = array(
      '#type' => 'tel',
      '#title' => t('Mobile No'),
      '#required' => TRUE,
      '#default_value' => $number,
    );
/*
    $form['candidate_dob'] = array(
      '#type' => 'date',
      '#title' => t('DOB'),
      // '#required' => TRUE,
    );

    $form['candidate_gender'] = array(
      '#type' => 'select',
      '#title' => ('Gender'),
      '#options' => array(
        'Female' => t('Male'),
        'male' => t('Female'),
        '#default_value' => $gender,
      ),
);
  
  */ 
    $form['submit'] = array(
      '#type' => 'submit',
      '#value' => t('edit'),
    );

    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function validateForm(array &$form, FormStateInterface $form_state) {
  }

  /**
   * {@inheritdoc}
   */
/*

public static function dbentry($entry = array()) {
    // Read all fields from the dbtng_example table.
   $select = db_select('dbtng_example', 'ef');
    $select->fields('ef');

    // Add each field and value as a condition to this query.
    foreach ($entry as $field => $value) {
      $select->condition($field, $value);
    }
    // Return the result in object format.
    return $select->execute()->fetchAll();
  }



  $Form_entries = array();
    foreach ($entries as $entry) {
         $entry->name,
         $entry->mail,
         $entry->number,
         $entry->candidate_dob,
         $entry->candidate_gender,
      );

      $keyed_entries[$entry->nid] = $entry;
    }


  $nid = $form_state->getValue('nid');


  $default_entry = !empty($pid) ? $keyed_entries[$nid] : $entries[0];

   $form_state->setValue('entries', $keyed_entries);


   $form['name'] = array(
      '#type' => 'textfield',
      '#title' => t('Updated first name'),
      '#size' => 15,
      '#default_value' => $default_entry->name,
    );

/*
   $form['mail'] = array(
      '#type' => 'email',
      '#title' => t('Updated email'),
      '#size' => 15,
      '#default_value' => $default_entry->mail,



   $form['number'] = array(
      '#type' => 'tel',
      '#title' => t('Mobile No'),
      '#size' => 15,
      '#default_value' => $default_entry->number,

    );

*/


public function submitForm(array &$form, FormStateInterface $form_state) {
    foreach ($form_state->getValues() as $key => $value) {
      drupal_set_message($key . ': ' . $value);
    }
  
      db_insert('ExampleForm')->fields(array(
       'name' => $form_state->getValue('candidate_name'),
       'gender' => $form_state->getValue('candidate_gender'),
       'email' => $form_state->getValue('candidate_mail'),
       'number' => $form_state->getValue('candidate_number'),   
     ))->execute();
     drupal_set_message(t('successfully entered the data'));

}
}

