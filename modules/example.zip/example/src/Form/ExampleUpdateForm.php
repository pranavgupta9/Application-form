<?php

namespace Drupal\example\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormState;
use Drupal\Core\Form\FormStateInterface;
use Drupal\example\controller\ExampleStorage;
use Symfony\Component\DependencyInjection\ContainerInterface;


/**
 * Sample UI to update a record.
 */
class ExampleUpdateForm extends FormBase {

  /**
   * {@inheritdoc}
   */

  public function getFormId() {
    return 'update_form';
  }

/**
   * Sample UI to update a record.
   */

  public function buildForm(array $form, FormStateInterface $form_state) {
    // Wrap the form in a div.
    $form = array(
      '#prefix' => '<div id="updateform">',
      '#suffix' => '</div>',
    );


    // Add some explanatory text to the form.
    $form['message'] = array(
      '#markup' => $this->t('select the name to edit operations.'),
    );



  // Query for items to display.

     $entries = ExampleStorage::load(); 
  
    // Tell the user if there is nothing to display.
     if (empty($entries)) {
      $form['no_values'] = array(
        '#value' => t('No entries exist in the table example table.'),
      );

      return $form;

    }

     $keyed_entries = array();
    foreach ($entries as $entry) {
      $options[$entry->nid] = t('@name ', array(

//  if you want add name number , nid , number aur email add it in @name, @number, etc.

        '@nid' => $entry->nid,
        '@name' => $entry->name,
        '@number' => $entry->number,
        '@email' => $entry->email,
      ));
      $keyed_entries[$entry->nid] = $entry;
    }


     // Grab the nid.
    $nid = $form_state->getValue('nid');
    // Use the nid to set the default entry for updating.
    $default_entry = !empty($nid) ? $keyed_entries[$nid] : $entries[0];

    // Save the entries into the $form_state. We do this so the AJAX callback
    // doesn't need to repeat the query.
    $form_state->setValue('entries', $keyed_entries);


     $form['nid'] = array(
      '#type' => 'select',
      '#options' => $options,
      '#title' => t('Choose entry to update'),
      '#default_value' => $default_entry->nid,
      '#ajax' => array(
        'wrapper' => 'updateform',
        'callback' => array($this, 'updateCallback'),
      ),
    );


      $form['name'] = array(
      '#type' => 'textfield',
      '#title' => t('Updated first name'),
      '#size' => 15,
      '#default_value' => $default_entry->name,
    );

      $form['number'] = array(
      '#type' => 'tel',
      '#title' => t('Updated mobile number'),
      '#size' => 15,
      '#default_value' => $default_entry->number,
    );


      $form['email'] = array(
      '#type' => 'email',
      '#title' => t('Updated email'),
      '#size' => 14,
      '#default_value' => $default_entry->age,
    );

      $form['submit'] = array(
      '#type' => 'submit',
      '#value' => t('Update'),
    );
    return $form;
  }


 /**
   * AJAX callback handler for the nid select.
   *
   * When the pid changes, populates the defaults from the database in the form.
   */
  public function updateCallback(array $form, FormStateInterface $form_state) {
    // Gather the DB results from $form_state.
    $entries = $form_state->getValue('entries');
    // Use the specific entry for this $form_state.
    $entry = $entries[$form_state->getValue('nid')];
    // Setting the #value of items is the only way I was able to figure out
    // to get replaced defaults on these items. #default_value will not do it
    // and shouldn't.
    foreach (array('name', 'number', 'email') as $item) {
      $form[$item]['#value'] = $entry->$item;
    }
    return $form;
  }

   /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    // Gather the current user so the new record has ownership.
    $account = $this->currentUser();
    // Save the submitted entry.
    $entry = array(
      'nid' => $form_state->getValue('nid'),
      'name' => $form_state->getValue('name'),
      'number' => $form_state->getValue('number'),
      'email' => $form_state->getValue('email'),
      // 'uid' => $account->id(),
    );
  
    $count = ExampleStorage::update($entry);
    drupal_set_message(t('Updated entry @entry (@count row updated)', array(
      '@count' => $count,
      '@entry' => print_r($entry, TRUE),
    )));


  }

}


