<?php
/**
* @file
* Contains \Drupal\resume\Form\ResumeForm.
*/

namespace Drupal\example\Controller;
use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Database\Connection;
use Drupal\Core\Database\Query\SelectInterface;
use Drupal\Core\Database\Query\Condition;
use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormState;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Database\Query\TableSortExtender;
use Drupal\Core\Database\Query\PagerSelectExtender;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Drupal\Core\Url;


class Databaselist extends ControllerBase {



  protected $database;

  /**
   * {@inheritdoc}
   */


  public static function create(ContainerInterface $container) {
    return new static(
      $container->get('database')
    );
  }

  /**
   * Constructs a \Drupal\simpletest\Form\SimpletestResultsForm object.
   *
   * @param \Drupal\Core\Database\Connection $database
   *   The database connection service.
   */


  public function __construct(Connection $database) {
    $this->database = $database;
  }



public static function provideData($nid) {

  $query = \Drupal::database()->select('exampleform', 'nfd');
  $query->fields('nfd', ['nid', 'name', 'email','number']);
  $query->condition('nfd.nid', $nid);
  $result = $query->execute()->fetchObject();
  return $result;
}


/*
 public static function deletedData($nid) {
  $query = \Drupal::database()->delete('exampleform');
  $query->condition('nid', $nid);
  $query->execute();
  */

  public function viewData() {

  $query = $this->database->select('exampleform','ef');
  $query->fields('ef', array('nid', 'name', 'email','number'));


  // Build the table header.
 
    $header = array(
    array('Nid', 'field' => 'nid'),
    t('Name'),
    t('Email'),
    t('Number'),
    t('Edit Operation'),
    t('Delete Operation'),
  );


  $table_sort = $query->extend('Drupal\Core\Database\Query\TableSortExtender')->orderByHeader($header);
  $pager = $table_sort->extend('Drupal\Core\Database\Query\PagerSelectExtender')->limit(8);
  $result = $pager->execute()->fetchAll();

  foreach($result as $row) {

    $rows[] = array(
      $row->nid,
      $row->name,
      $row->email,
      $row->number,

     \Drupal::l(t('Edit'), \Drupal\Core\Url::fromRoute('example.form_edit',array(), 
      array('query' => array('nid' => $row->nid)))),

     \Drupal::l(t('Delete'), \Drupal\Core\Url::fromRoute('example.form_delete',array(), 
      array('query' => array('delete_nid' => $row->nid)))),

    );
  }


  $build = array(
      '#markup' =>t('Results')
  );

  $build['exampleform_table'] = array(
    '#theme' => 'table', '#header' => $header,
      '#rows' => $rows,
  );
 $build['pager'] = array(
   '#type' => 'pager'
 );
 return $build;

}


/*
	public function myPage() {
    $element = array(
      '#markup' => 'Hello world!',
    );

    return $element;
  }

*/

}

