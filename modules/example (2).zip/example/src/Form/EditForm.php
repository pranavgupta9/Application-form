<?php
/**
 * @file
 * Contains \Drupal\example\Form\ContributeForm.
 */

namespace Drupal\example\Form;
use Drupal\Core\Database\Connection;
use Drupal\Core\Database\Query\SelectInterface;
use Drupal\Core\Database\Query\Condition;
use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormState;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Component\Utility\UrlHelper;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Drupal\Core\Url;
use Drupal\example\Controller\Databaselist;




    class EditForm extends FormBase {


    public function getFormId() {
    return 'edit_form';
    }

    public function buildForm(array $form, FormStateInterface $form_state) {


    $path = \Drupal::request()->getQueryString();
    $arg = explode('=', $path); 
    // $param_node = isset($arg[0]) ? $arg[0] : '';
    $nid = isset($arg[1]) ? $arg[1] : '';
    if (!empty($nid)) {
    //  if (!empty($nid) && $param_node == 'nid') {
    $data = Databaselist::provideData($nid);
    $name = $data->name;
    $email = $data->email;
    $number = $data->number;
    }

    else {
    $name = '';
    $email = '';
    $number = '';

    } 


    $form['node_id'] = array(
    '#type' => 'hidden',
    '#default_value' => $nid,
    );

    $form['candidate_name'] = array(
    '#type' => 'textfield',
    '#title' => t('Name'),
    '#required' => TRUE,
    '#default_value' => $name,
    );

    $form['candidate_mail'] = array(
    '#type' => 'email',
    '#title' => t('Email Id'),
    '#required' => TRUE,
    '#default_value' => $email,
    );

    $form['candidate_number'] = array(
    '#type' => 'tel',
    '#title' => t('Mobile No'),
    '#required' => TRUE,
    '#default_value' => $number,
    );



    $form['submit'] = array(
    '#type' => 'submit',
    '#value' => t('edit'),
    );

    return $form;
    }


    public function validateForm(array &$form, FormStateInterface $form_state) {
    }



    public function submitForm(array &$form, FormStateInterface $form_state) {


    $store = array(
    //'nid' => $form_state->getValue(''),
    'name' => $form_state->getValue('candidate_name'),
    'email' => $form_state->getValue('candidate_mail'),
    'number' => $form_state->getValue('candidate_number'),
    );



    $query = \Drupal::database()->update('exampleform');
    $query->fields($store);
    $query->condition('nid', $form_state->getValue('node_id'));
    $query->execute();
    return $this->redirect('example.form_operations');
    }
    }    




