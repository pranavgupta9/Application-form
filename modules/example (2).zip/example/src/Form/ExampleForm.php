<?php

namespace Drupal\example\Form;
use Drupal\Core\Database\Connection;
use Drupal\Core\Database\Query\SelectInterface;
use Drupal\Core\Database\Query\Condition;
use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormState;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Database\Query\TableSortExtender;
use Drupal\Core\Database\Query\PagerSelectExtender;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Drupal\Core\Url;

    class ExampleForm extends FormBase {


    public function getFormId() {
    return 'Example_form';
    }

    //form creation//

    public function buildForm(array $form, FormStateInterface $form_state) {


    $form['candidate_name'] = array(
    '#type' => 'textfield',
    '#title' => t('Name:'),
    '#required' => TRUE,
    );
    $form['candidate_mail'] = array(
    '#type' => 'email',
    '#title' => t('Email ID:'),
    '#required' => TRUE,
    );
    $form['candidate_number'] = array(
    '#type' => 'tel',
    '#title' => t('Mobile No'),
    '#required' => TRUE
    );

    $form['actions']['#type'] = 'actions';
    $form['actions']['submit'] = array(
    '#type' => 'submit',
    '#value' => $this->t('Save'),
    '#button_type' => 'primary',

    );

    return $form;

    }

    // submission

    public function submitForm(array &$form, FormStateInterface $form_state) {

    foreach ($form_state->getValues() as $key => $value) {
    drupal_set_message($key . ': ' . $value);

    }

    db_insert('ExampleForm')->fields(array(
    'name' => $form_state->getValue('candidate_name'),
    //'gender' => $form_state->getValue('candidate_gender'),
    'email' => $form_state->getValue('candidate_mail'),
    'number' => $form_state->getValue('candidate_number'),   
    ))->execute();

    }
    }
