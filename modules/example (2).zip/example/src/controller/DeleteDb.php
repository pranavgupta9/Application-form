<?php

namespace Drupal\example\Controller;
use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Database\Connection;
use Drupal\Core\Database\Query\SelectInterface;
use Drupal\Core\Database\Query\Condition;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Database\Query\TableSortExtender;
use Drupal\Core\Database\Query\PagerSelectExtender;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Drupal\Core\Url;



class DeleteDb extends ControllerBase {



  public static function deleteItem($nid) {
   
   $query = \Drupal::database()->delete('exampleform');
   $query->condition('nid', $nid, '=');
   $query->execute();
  
}

  public function deleteData() {
   $path = \Drupal::request()->getQueryString();
   $arg = explode('=', $path);
   $param_node = isset($arg[0]) ? $arg[0] : ''; 
   $nid = isset($arg[1]) ? $arg[1] : ''; 
 //  if ($param_node == 'delete_nid' && is_numeric($nid)) {
    self::deleteItem($nid);
    return $this->redirect('example.form_operations');
  // }
  // return $this->redirect('example.form_operations');
  }
}

