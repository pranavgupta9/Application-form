<?php

namespace Drupal\example\Controller;
use Drupal\Core\Controller\ControllerBase;
use Drupal\example\controller\ExampleStorage;
use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormState;
use Drupal\Core\Form\FormStateInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;



/**
 * Controller for DBTNG Example.
 */
class examplecontroller extends ControllerBase {
/**
   * Render a list of entries in the database.
   */

 public function entryList() {
    $content = array();

    $content['message'] = array(
      '#markup' => $this->t('List of all the update queries.'),
    );

    $rows = array();
    $headers = array(t('Id'), t('uid'), t('Name'), t('number'), t('email'));


    foreach ($entries = ExampleStorage::load() as $entry) {
      // Sanitize each entry.
      $rows[] = array_map('Drupal\Component\Utility\SafeMarkup::checkPlain', (array) $entry);
    }


    $content['table'] = array(
      '#type' => 'table',
      '#header' => $headers,
      '#rows' => $rows,
      '#empty' => t('No entries available.'),
    );

    // Don't cache this page.
    $content['#cache']['max-age'] = 0;

    return $content;
  }

/**
   * Render a filtered list of entries in the database.
   */

  public function entryAdvancedList() {
    
    $content = array();

    $content['message'] = array(
      '#markup' => $this->t('A list of entries in the database.') . ' ' .
      $this->t('The username of the person who created the entry.'),
    );

    $headers = array(
      t('nid'),
      t('Name'),
      t('number'),
      t('email'),
    );

    $rows = array();


    foreach ($entries = ExampleStorage::advancedLoad() as $entry) {
    // Sanitize each entry.
      $rows[] = array_map('Drupal\Component\Utility\SafeMarkup::checkPlain', $entry);
    }


     $content['table'] = array(
      '#type' => 'table',
      '#header' => $headers,
      '#rows' => $rows,
      
      // nid-id change
      
      '#attributes' => array('nid' => 'example-advanced-list'),
      '#empty' => t('No entries available.'),
    );

    // Don't cache this page.

    $content['#cache']['max-age'] = 0;
    return $content;
  }

}


